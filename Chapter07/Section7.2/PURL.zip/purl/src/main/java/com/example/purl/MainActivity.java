package com.example.purl;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.Button;

public class MainActivity extends ActionBarActivity {
	private Button btnURL=null;
	private Button btnURLCon=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("第七章 网络编程入门");
        btnURL=(Button)findViewById(R.id.btnURL);
        btnURLCon=(Button)findViewById(R.id.btnURLCon);        
        
        Button.OnClickListener listener = new Button.OnClickListener(){
			@Override
			public void onClick(View v) {
				if(v.getId()==R.id.btnURL){
					Intent intentURL=new Intent();
					intentURL.setClass(MainActivity.this, URLActivity.class);
					startActivity(intentURL);					
				}
				else if(v.getId()==R.id.btnURLCon)
				{
					Intent intentURLCon=new Intent();
					intentURLCon.setClass(MainActivity.this, URLConActivity.class);
					startActivity(intentURLCon);					
				}				
			}
        };
        
        btnURL.setOnClickListener(listener);
        btnURLCon.setOnClickListener(listener);
    }
    }
