package com.example.purl;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.widget.ImageView;

import java.io.InputStream;
import java.net.URL;

public class URLActivity extends ActionBarActivity {
	private ImageView imgV=null;
	private final String TAG = "URLActivity";
	private final String strWebSite="http://192.168.1.113:8088/test/oh.jpg";
	
	protected void onCreate(Bundle savedInstanceState) 
	{
	 super.onCreate(savedInstanceState);
     setContentView(R.layout.activity_url);
	 imgV=(ImageView)findViewById(R.id.imgV);
	 new Thread(){
		public void run(){
			  try
			    {	
					//URL url = new URL("http://www.w3school.com.cn/i/site_photoref.jpg");
				    URL url = new URL(strWebSite);
				    InputStream is = url.openStream();
				    Bitmap mBitmap = BitmapFactory.decodeStream(is);
				    if (mBitmap == null) {
	                    Log.v(TAG, "get pic failed");
	                }
				    else
				    {
				    	 Log.v(TAG, "get pic successfully");
				         imgV.setImageBitmap(mBitmap);
				    }
		       } 
				catch (Exception e) 
			   {
			        e.printStackTrace();
			   }
	      }
	 }.start();
  }
}
