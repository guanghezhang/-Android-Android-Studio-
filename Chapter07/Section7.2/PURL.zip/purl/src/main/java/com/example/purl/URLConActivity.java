package com.example.purl;

import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.widget.TextView;

public class URLConActivity extends ActionBarActivity {
	private TextView tvShowInfo=null;
	private String str="";
	private final String strWebSite="http://192.168.1.222:8088/test/index.html";
	 protected void onCreate(Bundle savedInstanceState) 
		{
		 super.onCreate(savedInstanceState);
	     setContentView(R.layout.activity_urlcon);
		 tvShowInfo=(TextView)findViewById(R.id.tvShowInfo);
		 new Thread(){
			public void run(){
				  try 
				  {
				    //URL url = new URL("http://www.w3school.com.cn/html/index.asp");
					  URL url = new URL(strWebSite);
				    URLConnection connection = url.openConnection();
				    InputStream is = connection.getInputStream();
				    byte[] bs = new byte[1024];
				    int len = 0;
				    StringBuffer sb = new StringBuffer();
				    while ((len = is.read(bs)) != -1) 
				    {
					     //String str = new String(bs, 0, len);
				    	 str = new String(bs, 0, len);
					     sb.append(str);
				    }
				    tvShowInfo.setText(sb.toString());
				  } 
				  catch (Exception e)
				  {			
				    e.printStackTrace();
				  }	          
		      }
		 }.start();
	  }




}
