package com.example.tcpclient;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.Socket;


public class MainActivity extends ActionBarActivity {
    private Button btnListen = null;
    private TextView tvShowInfo = null;
    private String strLine;
    private StringBuffer strBuffer = new StringBuffer();
    private String strContent = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tcpclient);
        setTitle("第七章 网络编程入门");
        tvShowInfo = (TextView) findViewById(R.id.tvSocketData);
        tvShowInfo.setText(strContent);

        btnListen = (Button) findViewById(R.id.btnListen);
        btnListen.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Socket socket = new Socket("192.168.1.222", 30000);
                            //BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                            Reader reader = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"));
                            BufferedReader bufReader = new BufferedReader(reader);
                            while ((strLine = bufReader.readLine()) != null) {
                                strBuffer.append(strLine);
                            }
                            if (bufReader != null) {
                                bufReader.close();
                            }
                            strContent = strBuffer.toString();
                            tvShowInfo.post(new Runnable() {
                                public void run() {
                                    tvShowInfo.setText(strContent);
                                }
                            });
                            // String line = bufferedReader.readLine();

                            bufReader.close();
                            socket.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }
        });
    }
}


