package com.example.emclient;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;


public class MainActivity extends ActionBarActivity {
    private TextView tvShowInfo = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("第七章 网络编程入门");
        tvShowInfo = (TextView) findViewById(R.id.tvShowInfo);
        //tvShowInfo.setText("");
        new Thread() {
            @Override
            public void run() {
                try {
                    Socket socket = new Socket("192.168.1.222", 30001);
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    String line = bufferedReader.readLine();
                    tvShowInfo.setText(line);
                    bufferedReader.close();
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

}
