package com.example;


import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;


public class TcpSocketServer {

    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(30000);
        while (true) {
            Socket socket = serverSocket.accept();
            OutputStream outputStream = socket.getOutputStream();
            InputStream inputStream = new FileInputStream("C://tcp.txt");
            byte data[] = new byte[1024];
            int i = 0;
            while ((i = inputStream.read(data)) != -1) {
                outputStream.write(data, 0, i);
            }
            //outputStream.write("This is an case".getBytes("utf-8"));
            outputStream.close();
            socket.close();
        }
    }
}
