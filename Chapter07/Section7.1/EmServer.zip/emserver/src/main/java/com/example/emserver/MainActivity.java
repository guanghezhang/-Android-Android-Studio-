package com.example.emserver;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;

import java.io.IOException;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;


public class MainActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("第七章 网络编程入门");
        new Thread() {
            public void run() {
                try {
                    ServerSocket serverSocket = new ServerSocket(30000);
                    while (true) {
                        Socket socket = serverSocket.accept();
                        OutputStream outputStream = socket.getOutputStream();
                        outputStream.write("This is a String for Test.".getBytes("utf-8"));
                        outputStream.close();
                        socket.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }
}


