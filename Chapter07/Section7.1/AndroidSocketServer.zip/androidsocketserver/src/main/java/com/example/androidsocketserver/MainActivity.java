package com.example.androidsocketserver;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.OutputStream;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.Enumeration;


public class MainActivity extends ActionBarActivity {
    private TextView tvShowInfo = null;
    private Button btnSender = null;
    private EditText etInput = null;
    private String strInput = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("第七章 网络编程入门");
        tvShowInfo = (TextView) findViewById(R.id.tvShowInfo);
        etInput = (EditText) findViewById(R.id.etInput);
        btnSender = (Button) findViewById(R.id.btnSender);
        tvShowInfo.setText("init");

        btnSender.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                strInput = etInput.getText().toString();
                tvShowInfo.setText(strInput);
                new Thread(new Runnable() {
                    public void run() {
                        try {
                            ServerSocket serverSocket = new ServerSocket(30000);
                            while (true) {
                                Socket socket = serverSocket.accept();
                                OutputStream outputStream = socket.getOutputStream();
                                if (strInput.equals("")) {
                                    strInput = "This is a case for Socket Communication between PC and Android";
                                }
                                outputStream.write(strInput.getBytes("utf-8"));
//        	    	        		 tvShowInfo.post(new Runnable(){
//        	    	        			 public void run(){
//        	    	        				 tvShowInfo.setText(strInput);
//        	    	        			 }
//        	    	        		 });
                                //outputStream.write("This is a case for Socket Communication between PC and Android".getBytes("utf-8"));
                                outputStream.close();
                                socket.close();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                }).start();
            }

        });
    }

    public String getLocalIpAddress() {
        try {
            for (Enumeration<NetworkInterface> en = NetworkInterface
                    .getNetworkInterfaces(); en.hasMoreElements(); ) {
                NetworkInterface intf = en.nextElement();
                for (Enumeration<InetAddress> enumIpAddr = intf
                        .getInetAddresses(); enumIpAddr.hasMoreElements(); ) {
                    InetAddress inetAddress = enumIpAddr.nextElement();
                    if (!inetAddress.isLoopbackAddress()) {
                        return inetAddress.getHostAddress().toString();
                    }
                }
            }
        } catch (SocketException ex) {
            Log.e("WifiPreference IpAddress", ex.toString());
        }
        return null;
    }
}
