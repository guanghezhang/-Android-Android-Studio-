package com.example.pwebview;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;

public class WebHtmlActivity extends ActionBarActivity {
	private TextView tvWebHttp=null;
	private Button btnLoadData=null;
	private Button btnLoadDataWithBaseURL=null;
	private WebView webViewHttp=null;
	private StringBuilder strBuilderDefault=null;
	private StringBuilder strBuilderLoadData=null;
	private StringBuilder strBuilderLoadDataWithBaseURL=null;
	
	protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webhttp);

        tvWebHttp=(TextView)findViewById(R.id.tvWebHttp);
        btnLoadData=(Button)findViewById(R.id.btnloadData);
        btnLoadDataWithBaseURL=(Button)findViewById(R.id.btnloadDataWithBaseURL);
        webViewHttp=(WebView)findViewById(R.id.webViewHttp);
        
        strBuilderDefault=new StringBuilder();
        strBuilderDefault.append("<div>");
        strBuilderDefault.append("<h1>案例的实现思路</h1>");
        strBuilderDefault.append("<p><b>Step 1</b>：创建strBuilder对象并向其中写入HTML代码；</p>");
        strBuilderDefault.append("<p><b>Step 2</b>：将HTML代码显示在TextView上；</p>");
        strBuilderDefault.append("<p><b>Step 3</b>：将对应的HTML代码显示在WebView上；</p>");
        tvWebHttp.setText(strBuilderDefault.toString());
        webViewHttp.loadDataWithBaseURL(null,strBuilderDefault.toString(), "text/html", "utf-8", null);
        
        
        Button.OnClickListener listener = new Button.OnClickListener(){
			@Override
			public void onClick(View v) {
				if(v.getId()==R.id.btnloadData){
					strBuilderLoadData=new StringBuilder();
			        strBuilderLoadData.append("<div>");
			        strBuilderLoadData.append("<h1>团队简介</h1>");
			        strBuilderLoadData.append("<p>OH简介:OH全称Our Home，由张光河于2011年创立,专注于以开发项目的方式引导其成员获得软件开发的能力,并学习如何在项目开发过程中找到值得研究的问题。</p><br>");
			        strBuilderLoadData.append("<h1>培养流程</h1>");
			        strBuilderLoadData.append("<p>大致分为三个阶段：【新手入门阶段】，【指定项目阶段】，【自由开发阶段】。</p><br> ");			        
			        strBuilderLoadData.append("<h1>目标人群</h1>");
			        strBuilderLoadData.append("<p>对软件开发有浓厚兴趣并愿意付出艰苦卓绝的努力的、没有任何编程基础的大一学生。<br>");			        
			        strBuilderLoadData.append("OH不设定任何门槛，只要有电脑的同学即可加入.</p>");
			        strBuilderLoadData.append("</div>");
			        tvWebHttp.setText(strBuilderLoadData.toString());
			        //webViewHttp.getSettings().setDefaultTextEncodingName("utf-8");			       
			        webViewHttp.loadData(strBuilderLoadData.toString(),"text/html; charset=UTF-8",null);
					//webViewHttp.loadData(strBuilderLoadData.toString(), "text/html", "charset=utf-8");
					
				}
			else if(v.getId()==R.id.btnloadDataWithBaseURL){
				    strBuilderLoadDataWithBaseURL=new StringBuilder();
			        strBuilderLoadDataWithBaseURL.append("<div>");
			        strBuilderLoadDataWithBaseURL.append("<img src=\"oh.jpg\">");
			        strBuilderLoadDataWithBaseURL.append("</div>");
			        strBuilderLoadDataWithBaseURL.append("<div>");
			        strBuilderLoadDataWithBaseURL.append("<ul>");
			        strBuilderLoadDataWithBaseURL.append("<li>主页</li>");
			        strBuilderLoadDataWithBaseURL.append("<li>课程学习</li>");
			        strBuilderLoadDataWithBaseURL.append("<li>作品展示</li>");
			        strBuilderLoadDataWithBaseURL.append("<li>编程乐园</li>");
			        strBuilderLoadDataWithBaseURL.append("</ul>");
			        strBuilderLoadDataWithBaseURL.append("</div>");
			        tvWebHttp.setText(strBuilderLoadDataWithBaseURL.toString());	
			        webViewHttp.getSettings().setDefaultTextEncodingName("utf-8");
					webViewHttp.loadDataWithBaseURL("file:///android_asset/",strBuilderLoadDataWithBaseURL.toString(), "text/html", "utf-8", null);
				}
				}
        };
        btnLoadData.setOnClickListener(listener);
        btnLoadDataWithBaseURL.setOnClickListener(listener);
	}

}
