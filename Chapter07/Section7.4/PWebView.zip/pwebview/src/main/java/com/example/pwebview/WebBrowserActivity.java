package com.example.pwebview;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class WebBrowserActivity extends ActionBarActivity {
	private WebView wvShowUrl=null;
	private Button btnUrlOk=null;
	private EditText etInputUrl=null;
	
    private String strUrl = "";
    
    
	 protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	    setContentView(R.layout.activity_webbrowser);
	    
	    etInputUrl=(EditText)findViewById(R.id.etUrl);
	    btnUrlOk=(Button)findViewById(R.id.btnUrlOk);
	    wvShowUrl=(WebView)findViewById(R.id.webViewShow);
	    
	    strUrl="http://192.168.1.222:8088/test/index.html";
	    
	    wvShowUrl.loadUrl(strUrl);
	    
	    
	    Button.OnClickListener listener = new Button.OnClickListener(){
			@Override
			public void onClick(View v) {
				if(v.getId()==R.id.btnUrlOk){
					strUrl=etInputUrl.getText().toString();
					if(!strUrl.equals(""))
					{
						wvShowUrl.loadUrl(strUrl);
					}
					else
					{
						Toast.makeText(getApplicationContext(), "��ַ������Ϊ��",Toast.LENGTH_SHORT).show();						
					}
				}
			 }
			};
			btnUrlOk.setOnClickListener(listener);
	 }
}
