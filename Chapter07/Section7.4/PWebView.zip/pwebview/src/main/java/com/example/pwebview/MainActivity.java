package com.example.pwebview;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.Button;


public class MainActivity extends ActionBarActivity {
    private Button btnWebBrowser=null;
    private Button btnWebHttp=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("第七章 网络编程入门");
        btnWebBrowser=(Button)findViewById(R.id.btnWebBrowser);
        btnWebHttp=(Button)findViewById(R.id.btnWebHtml);

        Button.OnClickListener listener = new Button.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(v.getId()==R.id.btnWebBrowser){
                    Intent intentWebBrowser=new Intent();
                    intentWebBrowser.setClass(MainActivity.this, WebBrowserActivity.class);
                    startActivity(intentWebBrowser);
                }
                else if(v.getId()==R.id.btnWebHtml)
                {
                    Intent intentWebHtml=new Intent();
                    intentWebHtml.setClass(MainActivity.this, WebHtmlActivity.class);
                    startActivity(intentWebHtml);
                }
            }
        };

        btnWebBrowser.setOnClickListener(listener);
        btnWebHttp.setOnClickListener(listener);
    }
}
